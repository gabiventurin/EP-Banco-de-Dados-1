﻿namespace Hotelaria.Services.Enum;

public enum SazonalidadeEnum
{
    Calor,
    Frio,
    Chuva
}
